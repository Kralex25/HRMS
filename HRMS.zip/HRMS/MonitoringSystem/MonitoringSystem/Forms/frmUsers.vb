﻿Public Class frmUsers
    Public state As String
    Public ID As Integer
    Dim User As New clsUsers

    Private Sub frmUsers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If state = "Add" Then
            Clear()
        Else
            fillControls()
        End If
    End Sub

    Sub fillControls()
        Dim list As ArrayList = User.GetUserByID(ID)
        For Each post As clsUsers In list
            txtUsername.Text = post.Username
            txtPassword.Text = post.Password
            cbUsertype.Text = post.Usertype
        Next
    End Sub
    Sub fillUsers()
        User.Username = txtUsername.Text
        User.Password = txtPassword.Text
        User.Usertype = cbUsertype.Text
    End Sub
    Sub Clear()
        Dim x, y As Control
        For Each x In Me.Controls
            If (TypeOf x Is GroupBox) Then
                For Each y In x.Controls
                    If (TypeOf y Is TextBox) Or (TypeOf y Is ComboBox) Then
                        y.Text = String.Empty
                    End If
                Next
            End If
        Next
    End Sub

    Private Sub btnsave_Click(sender As Object, e As EventArgs) Handles btnsave.Click
        fillUsers()
        If state = "Add" Then
            User.addUser()
            frmUserList.fillList()
            Clear()
        Else
            User.updateUser(ID)
            frmUserList.fillList()
            frmUserList.ID = Nothing
            Me.Close()
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        frmUserList.ID = Nothing
        Clear()
        Me.Close()
    End Sub

End Class