﻿Public Class frmEmpList
    Dim employee As New clsEmployees
    Public ID As Integer
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        With frmemployee
            .state = "Add"
            .ShowDialog(Me)
        End With
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        ID = Nothing
        Me.Close()
    End Sub

    Private Sub frmEmpList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fillList()
    End Sub

    Private Sub lvList_DoubleClick(sender As Object, e As EventArgs)
        btnEdit.PerformClick()
    End Sub

    Public Sub fillList()
        Dim List As List(Of clsEmployees) = employee.GetAllEmployees
        With lvList
            .Items.Clear()
            For Each post As clsEmployees In List
                Dim item As New ListViewItem
                item.Text = post.EmpID
                item.SubItems.Add(post.EmployeeID)
                item.SubItems.Add(post.Lastname)
                item.SubItems.Add(post.Firstname)
                item.SubItems.Add(post.MI)
                item.SubItems.Add(post.Sex)
                item.SubItems.Add(post.Position)
                item.SubItems.Add(post.Department)
                .Items.Add(item)
            Next
        End With
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        If Not ID = Nothing Then
            With frmEmployee
                .state = "Edit"
                .ID = Me.ID
                .ShowDialog(Me)
            End With
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

    Private Sub lvList_SelectedIndexChanged_1(sender As Object, e As EventArgs) Handles lvList.SelectedIndexChanged
        If lvList.SelectedItems.Count > 0 Then
            ID = CInt(lvList.SelectedItems(0).Text)
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If Not ID = Nothing Then
            employee.deleteEmployee(ID)
            ID = Nothing
            fillList()
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

End Class