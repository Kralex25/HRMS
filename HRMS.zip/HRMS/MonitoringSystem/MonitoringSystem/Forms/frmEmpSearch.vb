﻿Imports System.Windows.Forms

Public Class frmEmpSearch
    Dim ID As Integer
    Dim employee As New clsEmployees
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub lvList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvList.SelectedIndexChanged
        If lvList.SelectedItems.Count > 0 Then
            ID = CInt(lvList.SelectedItems(0).Text)
        End If
    End Sub

    Private Sub btnSelect_Click(sender As Object, e As EventArgs) Handles btnSelect.Click
        If Not ID = Nothing Then
            Dim list As ArrayList = employee.GetEmployeeByID(ID)
            For Each post As clsEmployees In list
                With frmleave
                    .eID = Me.ID
                    .txtEmployeeId.Text = post.EmployeeID
                    .txtName.Text = post.Lastname & ", " & post.Firstname & " " & post.MI
                    .txtDepartment.Text = post.Department
                    .txtPosition.Text = post.Position
                    .txtSalary.Text = post.Rate
                End With
            Next
            Me.Close()
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

    Private Sub frmEmpSearch_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        ID = Nothing
    End Sub

    Private Sub frmEmpSearch_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fillList()
    End Sub
    Public Sub fillList()
        Dim List As List(Of clsEmployees) = employee.GetAllEmployees
        With lvList
            .Items.Clear()
            For Each post As clsEmployees In List
                Dim item As New ListViewItem
                item.Text = post.EmpID
                item.SubItems.Add(post.EmployeeID)
                item.SubItems.Add(post.Lastname)
                item.SubItems.Add(post.Firstname)
                item.SubItems.Add(post.MI)
                item.SubItems.Add(post.Sex)
                item.SubItems.Add(post.Position)
                item.SubItems.Add(post.Department)
                .Items.Add(item)
            Next
        End With
    End Sub
End Class
