﻿Imports System.Windows.Forms

Public Class frmEditSettings
    Public form As String
    Public ID As Integer
    Dim pos As New clsPositions
    Dim dep As New clsDepartments
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If form = "Position" Then
            pos.Name = txtTitle.Text
            pos.updatePosition(ID)
            With frmsettings
                .PID = Nothing
                .fillPositions()
                .txtPosition.Clear()
            End With
            
        Else
            dep.Name = txtTitle.Text
            dep.updateDepartment(ID)
            With frmsettings
                .DID = Nothing
                .fillDepartments()
                .txtDepartment.Clear()
            End With
        End If
        Me.Close()
    End Sub

    Private Sub frmEditSettings_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If form = "Position" Then
            Dim List As ArrayList = pos.GetPositionbyID(ID)
            For Each post As clsPositions In List
                txtTitle.Text = post.Name
            Next
        Else
            Dim List As ArrayList = dep.GetDepartmentbyID(ID)
            For Each post As clsDepartments In List
                txtTitle.Text = post.Name
            Next
        End If
    End Sub
End Class
