﻿Public Class frmleave
    Public ID As Integer
    Public eID As Integer
    Private empid As Integer
    Public state As String
    Dim lve As New clsLeaves
    Dim emp As New clsEmployees
    Private Sub btnFind_Click(sender As Object, e As EventArgs) Handles btnFind.Click
        frmEmpSearch.ShowDialog(Me)
    End Sub

    Private Sub frmleave_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        rdoenabled()
    End Sub

    Private Sub frmleave_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If frmLogin.u.usertype = "Administrator" Then
            gbApproval.Visible = True
        Else
            gbApproval.Visible = False
        End If
        If state = "Add" Then
            Clear()
        Else
            fillControls()
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        frmLeaveAbsence.fillLeaves()
        Me.Close()
    End Sub
    Sub Clear()
        Dim x, y As Control
        For Each x In Me.Controls
            If (TypeOf x Is GroupBox) Then
                For Each y In x.Controls
                    If TypeOf y Is TextBox Then
                        y.Text = String.Empty
                    End If
                Next
            End If
        Next
    End Sub

    Private Sub btnsave_Click(sender As Object, e As EventArgs) Handles btnsave.Click
        fillLeaves()
        If state = "Add" Then
            If Not txtEmployeeId.Text = "" Then
                lve.addLeave()
                Clear()
            Else
                Exit Sub
            End If
        ElseIf state = "View" Then
            If rdoApproved.Checked = True Or rdoDisapproved.Checked = True Then
                If rdoApproved.Checked = True Then
                    lve.Status = "Approved"
                End If
                If rdoDisapproved.Checked = True Then
                    lve.Status = "Disapproved"
                End If
                lve.approveLeave(ID)
            End If
            frmLeaveAbsence.fillLeaves()
            frmLeaveAbsence.ID = Nothing
            eID = Nothing
            ID = Nothing
            Me.Close()
        Else
            lve.updateLeave(ID)
            frmLeaveAbsence.fillLeaves()
            frmLeaveAbsence.ID = Nothing
            eID = Nothing
            ID = Nothing
            Me.Close()
        End If
    End Sub

    Sub fillLeaves()
        If Not eID = Nothing Then
            empid = Nothing
            lve.EmpID = eID
        End If
        If Not empid = Nothing Then
            eID = Nothing
            lve.EmpID = empid
        End If
        If rdowithPay.Checked = True Then
            lve.Opt = "With Pay"
        End If
        If rdoWithoutPay.Checked = True Then
            lve.Opt = "Without Pay"
        End If
        If rdoVacation.Checked = True Then
            lve.Reason = "Vacation"
        End If
        If rdoSick.Checked = True Then
            lve.Reason = "Sick"
        End If
        If rdoForced.Checked = True Then
            lve.Reason = "Forced"
        End If
        If rdoPrivilege.Checked = True Then
            lve.Reason = "Priviledge"
        End If
        lve.SDate = dpSDate.Text
        lve.EDate = dpEDate.Text

        If state = "Add" Then
            lve.Status = "For Approval"
        End If
    End Sub

    Sub fillControls()
        Dim list As ArrayList = lve.GetLeavebyID(ID)
        For Each post As clsLeaves In list
            empid = post.EmpID
            If post.Opt = "With Pay" Then
                rdowithPay.Checked = True
            Else
                rdoWithoutPay.Checked = True
            End If

            If post.Reason = "Vacation" Then
                rdoVacation.Checked = True
            ElseIf post.Reason = "Sick" Then
                rdoSick.Checked = True
            ElseIf post.Reason = "Forced" Then
                rdoForced.Checked = True
            Else
                rdoPrivilege.Checked = True
            End If
            dpSDate.Value = post.SDate
            dpEDate.Value = post.EDate
        Next
        Dim elist As ArrayList = emp.GetEmployeeByID(empid)
        For Each epost As clsEmployees In elist
            txtEmployeeId.Text = epost.EmployeeID
            txtName.Text = epost.Lastname & ", " & epost.Firstname & " " & epost.MI
            txtDepartment.Text = epost.Department
            txtPosition.Text = epost.Position
            txtSalary.Text = epost.Rate
        Next
    End Sub
    Sub rdodisable()
        rdowithPay.Enabled = False
        rdoWithoutPay.Enabled = False
        rdoForced.Enabled = False
        rdoPrivilege.Enabled = False
        rdoSick.Enabled = False
        rdoVacation.Enabled = False
    End Sub
    Sub rdoenabled()
        rdowithPay.Enabled = True
        rdoWithoutPay.Enabled = True
        rdoForced.Enabled = True
        rdoPrivilege.Enabled = True
        rdoSick.Enabled = True
        rdoVacation.Enabled = True
    End Sub

    Private Sub rdoApproved_CheckedChanged(sender As Object, e As EventArgs) Handles rdoApproved.CheckedChanged

    End Sub
End Class