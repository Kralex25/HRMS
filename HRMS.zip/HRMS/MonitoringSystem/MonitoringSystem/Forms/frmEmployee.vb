﻿Public Class frmEmployee
    Public state As String
    Public ID As Integer
    Dim emp As New clsEmployees

    Private Sub btnlistemp_Click(sender As Object, e As EventArgs)
        frmEmpList.ShowDialog()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        fillEmployees()
        If state = "Add" Then
            emp.addEmployee()
            frmEmpList.fillList()
        Else

            emp.updateEmployee(ID)
            ID = Nothing
            Me.Close()
            frmEmpList.ID = Nothing
            frmEmpList.fillList()
        End If
    End Sub

    Private Sub frmemployee_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fillPosition()
        fillDepartment()
        rdoMale.Checked = True
        If state = "Add" Then
            Clear()
            txtRate.Text = "0.00"
        Else
            fillControls()
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Sub Clear()
        Dim x, y As Control
        For Each x In Me.Controls
            If (TypeOf x Is GroupBox) Then
                For Each y In x.Controls
                    If (TypeOf y Is TextBox) Or (TypeOf y Is ComboBox) Then
                        y.Text = String.Empty
                    End If
                Next
            End If
        Next
    End Sub

    Sub fillEmployees()
        Emp.EmployeeID = txtEmployeeID.Text
        Emp.Firstname = txtFname.Text
        Emp.Lastname = txtLname.Text
        Emp.MI = txtMI.Text
        Emp.Address = txtAddress.Text
        Emp.CivilStatus = cbCivilStatus.Text
        If rdoMale.Checked = True Then
            Emp.Sex = "Male"
        End If
        If rdoFemale.Checked = True Then
            Emp.Sex = "Female"
        End If
        Emp.Contact = txtContact.Text
        emp.Birthdate = dpBirthdate.Text
        Emp.Birthplace = txtBirthplace.Text
        Emp.EContact = txtEContact.Text
        Emp.Rate = Convert.ToDouble(txtRate.Text)
        Emp.Method = cbMethod.Text
        Emp.PositionID = cbPosition.SelectedValue
        Emp.DepartmentID = cbDepartment.SelectedValue
        emp.DateHired = dpDateHired.Text
        Emp.Status = cbStatus.Text
    End Sub
    Sub fillControls()
        Dim list As ArrayList = emp.GetEmployeeByID(ID)
        For Each post As clsEmployees In list
            txtEmployeeID.Text = post.EmployeeID
            txtFname.Text = post.Firstname
            txtLname.Text = post.Lastname
            txtMI.Text = post.MI
            txtAddress.Text = post.Address
            cbCivilStatus.Text = post.CivilStatus
            If post.Sex = "Male" Then
                rdoMale.Checked = True
            Else
                rdoFemale.Checked = True
            End If
            txtContact.Text = post.Contact
            dpBirthdate.Text = post.Birthdate
            txtBirthplace.Text = post.Birthplace
            txtEContact.Text = post.EContact
            txtRate.Text = post.Rate
            cbMethod.Text = post.Method
            cbPosition.Text = post.Position
            cbDepartment.Text = post.Department
            dpDateHired.Text = post.DateHired
            cbStatus.Text = post.Status
        Next
    End Sub

    Private Sub fillPosition()
        Dim dict As New Dictionary(Of Integer, String)
        Dim Position As New clsPositions
        Dim PosList As New List(Of clsPositions)
        PosList = Position.GetAllPositions
        If Not PosList.Count <= 0 Then
            For Each row In PosList
                dict.Add(row.PositionID, row.Name)
            Next
            cbPosition.DisplayMember = "Value"
            cbPosition.ValueMember = "Key"
            cbPosition.DataSource = New BindingSource(dict, Nothing)
        End If
    End Sub

    Private Sub fillDepartment()
        Dim dict As New Dictionary(Of Integer, String)
        Dim Department As New clsDepartments
        Dim DepList As New List(Of clsDepartments)
        DepList = Department.GetAllDepartments
        If Not DepList.Count <= 0 Then
            For Each row In DepList
                dict.Add(row.DepartmentID, row.Name)
            Next
            cbDepartment.DisplayMember = "Value"
            cbDepartment.ValueMember = "Key"
            cbDepartment.DataSource = New BindingSource(dict, Nothing)
        End If
    End Sub

    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        Clear()
    End Sub
End Class