﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmsettings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmsettings))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lvPositions = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.btnPDelete = New System.Windows.Forms.Button()
        Me.btnPUpdate = New System.Windows.Forms.Button()
        Me.btnPSave = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtPosition = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.lvDepartments = New System.Windows.Forms.ListView()
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.btnDDelete = New System.Windows.Forms.Button()
        Me.btnDUpdate = New System.Windows.Forms.Button()
        Me.btnDSave = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtDepartment = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lvPositions)
        Me.GroupBox1.Controls.Add(Me.btnPDelete)
        Me.GroupBox1.Controls.Add(Me.btnPUpdate)
        Me.GroupBox1.Controls.Add(Me.btnPSave)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtPosition)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(51, 25)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(318, 307)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Positions"
        '
        'lvPositions
        '
        Me.lvPositions.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader3})
        Me.lvPositions.FullRowSelect = True
        Me.lvPositions.GridLines = True
        Me.lvPositions.Location = New System.Drawing.Point(32, 81)
        Me.lvPositions.Name = "lvPositions"
        Me.lvPositions.Size = New System.Drawing.Size(199, 205)
        Me.lvPositions.TabIndex = 6
        Me.lvPositions.UseCompatibleStateImageBehavior = False
        Me.lvPositions.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "ID"
        Me.ColumnHeader1.Width = 0
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Title"
        Me.ColumnHeader3.Width = 200
        '
        'btnPDelete
        '
        Me.btnPDelete.BackColor = System.Drawing.Color.LightGreen
        Me.btnPDelete.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPDelete.Location = New System.Drawing.Point(237, 177)
        Me.btnPDelete.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnPDelete.Name = "btnPDelete"
        Me.btnPDelete.Size = New System.Drawing.Size(75, 40)
        Me.btnPDelete.TabIndex = 5
        Me.btnPDelete.Text = "Delete"
        Me.btnPDelete.UseVisualStyleBackColor = False
        '
        'btnPUpdate
        '
        Me.btnPUpdate.BackColor = System.Drawing.Color.LightGreen
        Me.btnPUpdate.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPUpdate.Location = New System.Drawing.Point(237, 129)
        Me.btnPUpdate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnPUpdate.Name = "btnPUpdate"
        Me.btnPUpdate.Size = New System.Drawing.Size(75, 40)
        Me.btnPUpdate.TabIndex = 4
        Me.btnPUpdate.Text = "Update"
        Me.btnPUpdate.UseVisualStyleBackColor = False
        '
        'btnPSave
        '
        Me.btnPSave.BackColor = System.Drawing.Color.LightGreen
        Me.btnPSave.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPSave.Location = New System.Drawing.Point(237, 81)
        Me.btnPSave.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnPSave.Name = "btnPSave"
        Me.btnPSave.Size = New System.Drawing.Size(75, 40)
        Me.btnPSave.TabIndex = 3
        Me.btnPSave.Text = "Save"
        Me.btnPSave.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(29, 54)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Title :"
        '
        'txtPosition
        '
        Me.txtPosition.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPosition.Location = New System.Drawing.Point(79, 44)
        Me.txtPosition.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtPosition.Multiline = True
        Me.txtPosition.Name = "txtPosition"
        Me.txtPosition.Size = New System.Drawing.Size(152, 26)
        Me.txtPosition.TabIndex = 2
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lvDepartments)
        Me.GroupBox2.Controls.Add(Me.btnDDelete)
        Me.GroupBox2.Controls.Add(Me.btnDUpdate)
        Me.GroupBox2.Controls.Add(Me.btnDSave)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.txtDepartment)
        Me.GroupBox2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(406, 25)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox2.Size = New System.Drawing.Size(319, 307)
        Me.GroupBox2.TabIndex = 7
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Departments"
        '
        'lvDepartments
        '
        Me.lvDepartments.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader2, Me.ColumnHeader4})
        Me.lvDepartments.FullRowSelect = True
        Me.lvDepartments.GridLines = True
        Me.lvDepartments.Location = New System.Drawing.Point(33, 81)
        Me.lvDepartments.Name = "lvDepartments"
        Me.lvDepartments.Size = New System.Drawing.Size(199, 205)
        Me.lvDepartments.TabIndex = 7
        Me.lvDepartments.UseCompatibleStateImageBehavior = False
        Me.lvDepartments.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "ID"
        Me.ColumnHeader2.Width = 0
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "Title"
        Me.ColumnHeader4.Width = 200
        '
        'btnDDelete
        '
        Me.btnDDelete.BackColor = System.Drawing.Color.LightGreen
        Me.btnDDelete.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDDelete.Location = New System.Drawing.Point(238, 177)
        Me.btnDDelete.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnDDelete.Name = "btnDDelete"
        Me.btnDDelete.Size = New System.Drawing.Size(75, 40)
        Me.btnDDelete.TabIndex = 5
        Me.btnDDelete.Text = "Delete"
        Me.btnDDelete.UseVisualStyleBackColor = False
        '
        'btnDUpdate
        '
        Me.btnDUpdate.BackColor = System.Drawing.Color.LightGreen
        Me.btnDUpdate.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDUpdate.Location = New System.Drawing.Point(238, 129)
        Me.btnDUpdate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnDUpdate.Name = "btnDUpdate"
        Me.btnDUpdate.Size = New System.Drawing.Size(75, 40)
        Me.btnDUpdate.TabIndex = 4
        Me.btnDUpdate.Text = "Update"
        Me.btnDUpdate.UseVisualStyleBackColor = False
        '
        'btnDSave
        '
        Me.btnDSave.BackColor = System.Drawing.Color.LightGreen
        Me.btnDSave.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDSave.Location = New System.Drawing.Point(238, 81)
        Me.btnDSave.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnDSave.Name = "btnDSave"
        Me.btnDSave.Size = New System.Drawing.Size(75, 40)
        Me.btnDSave.TabIndex = 3
        Me.btnDSave.Text = "Save"
        Me.btnDSave.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(43, 54)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 16)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Name :"
        '
        'txtDepartment
        '
        Me.txtDepartment.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDepartment.Location = New System.Drawing.Point(102, 44)
        Me.txtDepartment.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtDepartment.Multiline = True
        Me.txtDepartment.Name = "txtDepartment"
        Me.txtDepartment.Size = New System.Drawing.Size(130, 26)
        Me.txtDepartment.TabIndex = 2
        '
        'frmsettings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Green
        Me.ClientSize = New System.Drawing.Size(779, 372)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MaximizeBox = False
        Me.Name = "frmsettings"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Settings"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btnPSave As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtPosition As System.Windows.Forms.TextBox
    Friend WithEvents btnPDelete As System.Windows.Forms.Button
    Friend WithEvents btnPUpdate As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents btnDDelete As System.Windows.Forms.Button
    Friend WithEvents btnDUpdate As System.Windows.Forms.Button
    Friend WithEvents btnDSave As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtDepartment As System.Windows.Forms.TextBox
    Friend WithEvents lvPositions As System.Windows.Forms.ListView
    Friend WithEvents lvDepartments As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
End Class
