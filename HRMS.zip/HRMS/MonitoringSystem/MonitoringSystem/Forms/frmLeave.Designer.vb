﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmleave
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmleave))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtEmployeeId = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.dtpApplied = New System.Windows.Forms.DateTimePicker()
        Me.txtPosition = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtSalary = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtDepartment = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnFind = New System.Windows.Forms.Button()
        Me.gbLeave = New System.Windows.Forms.GroupBox()
        Me.rdoPrivilege = New System.Windows.Forms.RadioButton()
        Me.rdoForced = New System.Windows.Forms.RadioButton()
        Me.rdoVacation = New System.Windows.Forms.RadioButton()
        Me.rdoSick = New System.Windows.Forms.RadioButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.rdoWithoutPay = New System.Windows.Forms.RadioButton()
        Me.rdowithPay = New System.Windows.Forms.RadioButton()
        Me.gbApproval = New System.Windows.Forms.GroupBox()
        Me.rdoDisapproved = New System.Windows.Forms.RadioButton()
        Me.rdoApproved = New System.Windows.Forms.RadioButton()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnsave = New System.Windows.Forms.Button()
        Me.gbDate = New System.Windows.Forms.GroupBox()
        Me.dpEDate = New System.Windows.Forms.DateTimePicker()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.dpSDate = New System.Windows.Forms.DateTimePicker()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label12 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.gbLeave.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.gbApproval.SuspendLayout()
        Me.gbDate.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(5, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(45, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Date :"
        '
        'txtEmployeeId
        '
        Me.txtEmployeeId.Enabled = False
        Me.txtEmployeeId.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmployeeId.Location = New System.Drawing.Point(135, 27)
        Me.txtEmployeeId.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtEmployeeId.Multiline = True
        Me.txtEmployeeId.Name = "txtEmployeeId"
        Me.txtEmployeeId.Size = New System.Drawing.Size(148, 26)
        Me.txtEmployeeId.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(36, 33)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(96, 16)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Employee ID :"
        '
        'dtpApplied
        '
        Me.dtpApplied.Location = New System.Drawing.Point(54, 15)
        Me.dtpApplied.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.dtpApplied.Name = "dtpApplied"
        Me.dtpApplied.Size = New System.Drawing.Size(266, 22)
        Me.dtpApplied.TabIndex = 5
        '
        'txtPosition
        '
        Me.txtPosition.Enabled = False
        Me.txtPosition.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPosition.Location = New System.Drawing.Point(479, 25)
        Me.txtPosition.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtPosition.Multiline = True
        Me.txtPosition.Name = "txtPosition"
        Me.txtPosition.Size = New System.Drawing.Size(239, 26)
        Me.txtPosition.TabIndex = 8
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(406, 35)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(67, 16)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Position :"
        '
        'txtSalary
        '
        Me.txtSalary.Enabled = False
        Me.txtSalary.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSalary.Location = New System.Drawing.Point(479, 59)
        Me.txtSalary.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtSalary.Multiline = True
        Me.txtSalary.Name = "txtSalary"
        Me.txtSalary.Size = New System.Drawing.Size(239, 26)
        Me.txtSalary.TabIndex = 12
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(416, 67)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 16)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Salary :"
        '
        'txtDepartment
        '
        Me.txtDepartment.Enabled = False
        Me.txtDepartment.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDepartment.Location = New System.Drawing.Point(135, 87)
        Me.txtDepartment.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtDepartment.Multiline = True
        Me.txtDepartment.Name = "txtDepartment"
        Me.txtDepartment.Size = New System.Drawing.Size(240, 26)
        Me.txtDepartment.TabIndex = 10
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(42, 93)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(90, 16)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "Department :"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtName)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.btnFind)
        Me.GroupBox1.Controls.Add(Me.txtSalary)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtDepartment)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.txtEmployeeId)
        Me.GroupBox1.Controls.Add(Me.txtPosition)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(16, 42)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(740, 135)
        Me.GroupBox1.TabIndex = 13
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Employee's Details"
        '
        'txtName
        '
        Me.txtName.Enabled = False
        Me.txtName.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName.Location = New System.Drawing.Point(135, 57)
        Me.txtName.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtName.Multiline = True
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(239, 26)
        Me.txtName.TabIndex = 16
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(79, 63)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 16)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "Name :"
        '
        'btnFind
        '
        Me.btnFind.Location = New System.Drawing.Point(289, 26)
        Me.btnFind.Name = "btnFind"
        Me.btnFind.Size = New System.Drawing.Size(56, 27)
        Me.btnFind.TabIndex = 14
        Me.btnFind.Text = "Find"
        Me.btnFind.UseVisualStyleBackColor = True
        '
        'gbLeave
        '
        Me.gbLeave.Controls.Add(Me.rdoPrivilege)
        Me.gbLeave.Controls.Add(Me.rdoForced)
        Me.gbLeave.Controls.Add(Me.rdoVacation)
        Me.gbLeave.Controls.Add(Me.rdoSick)
        Me.gbLeave.Controls.Add(Me.GroupBox3)
        Me.gbLeave.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbLeave.Location = New System.Drawing.Point(14, 185)
        Me.gbLeave.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.gbLeave.Name = "gbLeave"
        Me.gbLeave.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.gbLeave.Size = New System.Drawing.Size(742, 106)
        Me.gbLeave.TabIndex = 14
        Me.gbLeave.TabStop = False
        Me.gbLeave.Text = "Leave Applied For"
        '
        'rdoPrivilege
        '
        Me.rdoPrivilege.AutoSize = True
        Me.rdoPrivilege.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdoPrivilege.Location = New System.Drawing.Point(354, 67)
        Me.rdoPrivilege.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rdoPrivilege.Name = "rdoPrivilege"
        Me.rdoPrivilege.Size = New System.Drawing.Size(83, 20)
        Me.rdoPrivilege.TabIndex = 5
        Me.rdoPrivilege.TabStop = True
        Me.rdoPrivilege.Text = "Privilege"
        Me.rdoPrivilege.UseVisualStyleBackColor = True
        '
        'rdoForced
        '
        Me.rdoForced.AutoSize = True
        Me.rdoForced.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdoForced.Location = New System.Drawing.Point(255, 67)
        Me.rdoForced.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rdoForced.Name = "rdoForced"
        Me.rdoForced.Size = New System.Drawing.Size(70, 20)
        Me.rdoForced.TabIndex = 4
        Me.rdoForced.TabStop = True
        Me.rdoForced.Text = "Forced"
        Me.rdoForced.UseVisualStyleBackColor = True
        '
        'rdoVacation
        '
        Me.rdoVacation.AutoSize = True
        Me.rdoVacation.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdoVacation.Location = New System.Drawing.Point(255, 39)
        Me.rdoVacation.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rdoVacation.Name = "rdoVacation"
        Me.rdoVacation.Size = New System.Drawing.Size(81, 20)
        Me.rdoVacation.TabIndex = 3
        Me.rdoVacation.TabStop = True
        Me.rdoVacation.Text = "Vacation"
        Me.rdoVacation.UseVisualStyleBackColor = True
        '
        'rdoSick
        '
        Me.rdoSick.AutoSize = True
        Me.rdoSick.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdoSick.Location = New System.Drawing.Point(354, 39)
        Me.rdoSick.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rdoSick.Name = "rdoSick"
        Me.rdoSick.Size = New System.Drawing.Size(53, 20)
        Me.rdoSick.TabIndex = 2
        Me.rdoSick.TabStop = True
        Me.rdoSick.Text = "Sick"
        Me.rdoSick.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.rdoWithoutPay)
        Me.GroupBox3.Controls.Add(Me.rdowithPay)
        Me.GroupBox3.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(17, 19)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox3.Size = New System.Drawing.Size(215, 80)
        Me.GroupBox3.TabIndex = 1
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Option"
        '
        'rdoWithoutPay
        '
        Me.rdoWithoutPay.AutoSize = True
        Me.rdoWithoutPay.Location = New System.Drawing.Point(40, 48)
        Me.rdoWithoutPay.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rdoWithoutPay.Name = "rdoWithoutPay"
        Me.rdoWithoutPay.Size = New System.Drawing.Size(103, 20)
        Me.rdoWithoutPay.TabIndex = 0
        Me.rdoWithoutPay.TabStop = True
        Me.rdoWithoutPay.Text = "Without Pay"
        Me.rdoWithoutPay.UseVisualStyleBackColor = True
        '
        'rdowithPay
        '
        Me.rdowithPay.AutoSize = True
        Me.rdowithPay.Location = New System.Drawing.Point(40, 20)
        Me.rdowithPay.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rdowithPay.Name = "rdowithPay"
        Me.rdowithPay.Size = New System.Drawing.Size(83, 20)
        Me.rdowithPay.TabIndex = 0
        Me.rdowithPay.TabStop = True
        Me.rdowithPay.Text = "With Pay"
        Me.rdowithPay.UseVisualStyleBackColor = True
        '
        'gbApproval
        '
        Me.gbApproval.Controls.Add(Me.rdoDisapproved)
        Me.gbApproval.Controls.Add(Me.rdoApproved)
        Me.gbApproval.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbApproval.Location = New System.Drawing.Point(71, 368)
        Me.gbApproval.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.gbApproval.Name = "gbApproval"
        Me.gbApproval.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.gbApproval.Size = New System.Drawing.Size(636, 76)
        Me.gbApproval.TabIndex = 15
        Me.gbApproval.TabStop = False
        Me.gbApproval.Tag = "Reasons"
        Me.gbApproval.Text = "Approval"
        Me.gbApproval.Visible = False
        '
        'rdoDisapproved
        '
        Me.rdoDisapproved.AutoSize = True
        Me.rdoDisapproved.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdoDisapproved.Location = New System.Drawing.Point(479, 27)
        Me.rdoDisapproved.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rdoDisapproved.Name = "rdoDisapproved"
        Me.rdoDisapproved.Size = New System.Drawing.Size(105, 20)
        Me.rdoDisapproved.TabIndex = 7
        Me.rdoDisapproved.TabStop = True
        Me.rdoDisapproved.Text = "Disapproved"
        Me.rdoDisapproved.UseVisualStyleBackColor = True
        '
        'rdoApproved
        '
        Me.rdoApproved.AutoSize = True
        Me.rdoApproved.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdoApproved.Location = New System.Drawing.Point(107, 27)
        Me.rdoApproved.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rdoApproved.Name = "rdoApproved"
        Me.rdoApproved.Size = New System.Drawing.Size(87, 20)
        Me.rdoApproved.TabIndex = 6
        Me.rdoApproved.TabStop = True
        Me.rdoApproved.Text = "Approved"
        Me.rdoApproved.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.BackColor = System.Drawing.Color.LightGreen
        Me.btnClose.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(655, 452)
        Me.btnClose.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(101, 42)
        Me.btnClose.TabIndex = 18
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'btnsave
        '
        Me.btnsave.BackColor = System.Drawing.Color.LightGreen
        Me.btnsave.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsave.Location = New System.Drawing.Point(550, 452)
        Me.btnsave.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(99, 42)
        Me.btnsave.TabIndex = 18
        Me.btnsave.Text = "Save"
        Me.btnsave.UseVisualStyleBackColor = False
        '
        'gbDate
        '
        Me.gbDate.Controls.Add(Me.dpEDate)
        Me.gbDate.Controls.Add(Me.Label13)
        Me.gbDate.Controls.Add(Me.dpSDate)
        Me.gbDate.Controls.Add(Me.Label10)
        Me.gbDate.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbDate.Location = New System.Drawing.Point(71, 298)
        Me.gbDate.Name = "gbDate"
        Me.gbDate.Size = New System.Drawing.Size(636, 63)
        Me.gbDate.TabIndex = 25
        Me.gbDate.TabStop = False
        Me.gbDate.Text = "                              From                                               " & _
    "                              To"
        '
        'dpEDate
        '
        Me.dpEDate.CustomFormat = "MM/dd/yyyy"
        Me.dpEDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dpEDate.Location = New System.Drawing.Point(432, 21)
        Me.dpEDate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.dpEDate.Name = "dpEDate"
        Me.dpEDate.Size = New System.Drawing.Size(161, 22)
        Me.dpEDate.TabIndex = 30
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(353, 25)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(73, 16)
        Me.Label13.TabIndex = 29
        Me.Label13.Text = "End Date :"
        '
        'dpSDate
        '
        Me.dpSDate.CustomFormat = "MM/dd/yyyy"
        Me.dpSDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dpSDate.Location = New System.Drawing.Point(135, 22)
        Me.dpSDate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.dpSDate.Name = "dpSDate"
        Me.dpSDate.Size = New System.Drawing.Size(201, 22)
        Me.dpSDate.TabIndex = 28
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(25, 26)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(88, 16)
        Me.Label10.TabIndex = 27
        Me.Label10.Text = "Leave Date :"
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Bernard MT Condensed", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(8, 7)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(389, 32)
        Me.Label12.TabIndex = 26
        Me.Label12.Text = "Add Leave of Absence"
        '
        'frmleave
        '
        Me.AcceptButton = Me.btnsave
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Green
        Me.ClientSize = New System.Drawing.Size(774, 501)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.gbDate)
        Me.Controls.Add(Me.btnsave)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.gbApproval)
        Me.Controls.Add(Me.dtpApplied)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.gbLeave)
        Me.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MaximizeBox = False
        Me.Name = "frmleave"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Leave Application Form"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.gbLeave.ResumeLayout(False)
        Me.gbLeave.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.gbApproval.ResumeLayout(False)
        Me.gbApproval.PerformLayout()
        Me.gbDate.ResumeLayout(False)
        Me.gbDate.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtEmployeeId As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents dtpApplied As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtPosition As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtSalary As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtDepartment As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents gbLeave As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoWithoutPay As System.Windows.Forms.RadioButton
    Friend WithEvents rdowithPay As System.Windows.Forms.RadioButton
    Friend WithEvents rdoPrivilege As System.Windows.Forms.RadioButton
    Friend WithEvents rdoForced As System.Windows.Forms.RadioButton
    Friend WithEvents rdoVacation As System.Windows.Forms.RadioButton
    Friend WithEvents rdoSick As System.Windows.Forms.RadioButton
    Friend WithEvents gbApproval As System.Windows.Forms.GroupBox
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents gbDate As System.Windows.Forms.GroupBox
    Friend WithEvents dpSDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents dpEDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents btnFind As System.Windows.Forms.Button
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents rdoDisapproved As System.Windows.Forms.RadioButton
    Friend WithEvents rdoApproved As System.Windows.Forms.RadioButton
End Class
