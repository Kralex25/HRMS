﻿Imports System.Windows.Forms

Public Class frmUserList
    Public ID As Integer
    Dim User As New clsUsers
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        With frmUsers
            .state = "Add"
            .ShowDialog(Me)
        End With
    End Sub

    Private Sub lvList_DoubleClick(sender As Object, e As EventArgs) Handles lvList.DoubleClick
        btnEdit.PerformClick()
    End Sub

    Private Sub lvList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvList.SelectedIndexChanged
        If lvList.SelectedItems.Count > 0 Then
            ID = CInt(lvList.SelectedItems(0).Text)
        End If
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        If Not ID = Nothing Then
            With frmUsers
                .state = "Edit"
                .ID = Me.ID
                .ShowDialog()
            End With
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If Not ID = Nothing Then
            User.deleteUser(ID)
            fillList()
            ID = Nothing
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

    Private Sub frmUserList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fillList()
    End Sub
    Public Sub fillList()
        Dim List As List(Of clsUsers) = User.GetAllUsers
        With lvList
            .Items.Clear()
            For Each post As clsUsers In List
                Dim item As New ListViewItem
                item.Text = post.UserID
                item.SubItems.Add(post.Username)
                item.SubItems.Add(post.Password)
                item.SubItems.Add(post.Usertype)
                .Items.Add(item)
            Next
        End With
    End Sub
End Class
