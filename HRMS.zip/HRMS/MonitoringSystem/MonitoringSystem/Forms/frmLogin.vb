﻿Public Class frmLogin
    Dim user As New clsUsers
    Public u As userInfo
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim list As ArrayList = user.LogUser(txtUsername.Text, txtPassword.Text)
        If Not list.Count = 0 Then
            For Each post As clsUsers In list
                u.usertype = post.Usertype
            Next
            frmMain.Show()
            Me.Hide()
        Else
            MsgBox("Invalid Username or Password", MsgBoxStyle.Critical)
            txtUsername.Clear()
            txtPassword.Clear()
            txtUsername.Focus()
        End If
    End Sub

    Private Sub Cancel_Click(sender As Object, e As EventArgs) Handles Cancel.Click
        Application.Exit()
    End Sub

    Private Sub frmLogin_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Application.Exit()
    End Sub
End Class
