﻿Imports Microsoft.Reporting.WinForms
Public Class frmLeaveAbsence
    Public ID As Integer
    Dim lve As New clsLeaves
    Dim printstatus As String
    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        With frmleave
            .state = "Add"
            .ShowDialog()
        End With
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub lvList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvList.SelectedIndexChanged
        If lvList.SelectedItems.Count > 0 Then
            ID = CInt(lvList.SelectedItems(0).Text)
        End If
    End Sub

    Private Sub frmLeaveAbsence_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If frmLogin.u.usertype = "Administrator" Then
            btnadd.Visible = False
            btnUpdate.Visible = False
            btnDelete.Visible = False
        End If
        fillLeaves()
    End Sub

    Public Sub fillLeaves()
        Dim List As List(Of clsLeaves) = lve.GetAllLeaves
        With lvList
            .Items.Clear()
            For Each post As clsLeaves In List
                Dim item As New ListViewItem
                item.Text = post.LeaveID
                item.SubItems.Add(post.EmployeeID)
                item.SubItems.Add(post.Name)
                item.SubItems.Add(post.Opt)
                item.SubItems.Add(post.SDate)
                item.SubItems.Add(post.EDate)
                item.SubItems.Add(post.Reason)
                item.SubItems.Add(post.Status)
                .Items.Add(item)
            Next
        End With
    End Sub
    Public Sub fillLeavesWithReason(ByVal reason As String)
        Dim list As List(Of clsLeaves) = lve.GetLeavebyReason(reason)
        With lvList
            .Items.Clear()
            For Each post As clsLeaves In list
                Dim item As New ListViewItem
                item.Text = post.LeaveID
                item.SubItems.Add(post.EmployeeID)
                item.SubItems.Add(post.Name)
                item.SubItems.Add(post.Opt)
                item.SubItems.Add(post.SDate)
                item.SubItems.Add(post.EDate)
                item.SubItems.Add(post.Reason)
                item.SubItems.Add(post.Status)
                .Items.Add(item)
            Next
        End With
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If Not ID = Nothing Then
            With frmleave
                .state = "Edit"
                .ID = Me.ID
                .ShowDialog(Me)
            End With
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If Not ID = Nothing Then
            lve.deleteLeave(ID)
            fillLeaves()
            ID = Nothing
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

    Private Sub btnView_Click(sender As Object, e As EventArgs) Handles btnView.Click
        If Not ID = Nothing Then
            With frmleave
                .state = "View"
                .ID = Me.ID
                .ShowDialog(Me)
            End With
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

    Private Sub chkVacation_CheckedChanged(sender As Object, e As EventArgs) Handles chkVacation.CheckedChanged
        fillLeavesWithReason("Vacation")
        printstatus = "Vacation"
        chkSick.Checked = False
        chkForced.Checked = False
        chkPrivilege.Checked = False
    End Sub

    Private Sub chkSick_CheckedChanged(sender As Object, e As EventArgs) Handles chkSick.CheckedChanged
        fillLeavesWithReason("Sick")
        printstatus = "Sick"
        chkVacation.Checked = False
        chkForced.Checked = False
        chkPrivilege.Checked = False
    End Sub


    Private Sub chkForced_CheckedChanged(sender As Object, e As EventArgs) Handles chkForced.CheckedChanged
        fillLeavesWithReason("Forced")
        printstatus = "Force"
        chkVacation.Checked = False
        chkSick.Checked = False
        chkPrivilege.Checked = False
    End Sub

    Private Sub chkPrivilege_CheckedChanged(sender As Object, e As EventArgs) Handles chkPrivilege.CheckedChanged
        fillLeavesWithReason("Privilege")
        printstatus = "Privilege"
        chkVacation.Checked = False
        chkSick.Checked = False
        chkForced.Checked = False
    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        Dim rds As New ReportDataSource
        Dim vlist As List(Of clsLeaves) = lve.GetLeavebyReason("Vacation")
        Dim slist As List(Of clsLeaves) = lve.GetLeavebyReason("Sick")
        Dim flist As List(Of clsLeaves) = lve.GetLeavebyReason("Forced")
        Dim plist As List(Of clsLeaves) = lve.GetLeavebyReason("Privilege")
        Dim rptSource As String = ""
        If printstatus = "Vacation" Then
            rptSource = "MonitoringSystem.rptVacation.rdlc"
        ElseIf printstatus = "Sick" Then
            rptSource = "MonitoringSystem.rptSick.rdlc"
        ElseIf printstatus = "Forced" Then
            rptSource = "MonitoringSystem.rptForced.rdlc"
        Else
            rptSource = "MonitoringSystem.rptPrivilege.rdlc"
        End If
        With frmPrint
            With .rvPrint
                .LocalReport.ReportEmbeddedResource = rptSource
                rds.Name = "DataSet1"
                If printstatus = "Vacation" Then
                    rds.Value = vlist
                ElseIf printstatus = "Sick" Then
                    rds.Value = slist
                ElseIf printstatus = "Forced" Then
                    rds.Value = flist
                Else
                    rds.Value = plist
                End If
                .LocalReport.DataSources.Clear()
                .LocalReport.DataSources.Add(rds)
                .LocalReport.Refresh()
                .DocumentMapCollapsed = True
                .SetDisplayMode(DisplayMode.PrintLayout)
                .RefreshReport()
            End With
            .ShowDialog(Me)
        End With
    End Sub
End Class