﻿Public Class frmMain

    Private Sub btnEmployees_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEmployees.Click
        With frmEmpList
            .ShowDialog(Me)
        End With
    End Sub

    Private Sub btnLeaveOfAbsence_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLeaveOfAbsence.Click
        With frmLeaveAbsence
            .Show()
            .Focus()
        End With
    End Sub

    Private Sub btnMaintenance_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMaintenance.Click
        With frmsettings
            .Show()
            .Focus()
        End With
    End Sub

    Private Sub btnManageUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnManageUser.Click
        With frmUserList
            .Show()
            .Focus()
        End With
    End Sub

   
    Private Sub frmMain_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Application.Exit()
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        Application.Exit()
    End Sub

    Private Sub btnReport_Click(sender As Object, e As EventArgs)

    End Sub
End Class
