﻿Public Class frmsettings
    Public PID, DID As Integer
    Dim pos As New clsPositions
    Dim dep As New clsDepartments

    Private Sub lvPositions_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvPositions.SelectedIndexChanged
        If lvPositions.SelectedItems.Count > 0 Then
            PID = CInt(lvPositions.SelectedItems(0).Text)
        End If
    End Sub

    Private Sub lvDepartments_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvDepartments.SelectedIndexChanged
        If lvDepartments.SelectedItems.Count > 0 Then
            DID = CInt(lvDepartments.SelectedItems(0).Text)
        End If
    End Sub

    Private Sub btnPSave_Click(sender As Object, e As EventArgs) Handles btnPSave.Click
        pos.Name = txtPosition.Text
        pos.addPosition()
        fillPositions()
        Me.txtPosition.Clear()
    End Sub

    Private Sub btndeptSave_Click(sender As Object, e As EventArgs) Handles btnDSave.Click
        dep.Name = txtDepartment.Text
        dep.addDepartment()
        fillDepartments()
        Me.txtDepartment.Clear()
    End Sub

    Public Sub fillPositions()
        Dim List As List(Of clsPositions) = pos.GetAllPositions
        With lvPositions
            .Items.Clear()
            For Each post As clsPositions In List
                Dim item As New ListViewItem
                item.Text = post.PositionID
                item.SubItems.Add(post.Name)
                .Items.Add(item)
            Next
        End With
    End Sub

    Public Sub fillDepartments()
        Dim List As List(Of clsDepartments) = dep.GetAllDepartments
        With lvDepartments
            .Items.Clear()
            For Each post As clsDepartments In List
                Dim item As New ListViewItem
                item.Text = post.DepartmentID
                item.SubItems.Add(post.Name)
                .Items.Add(item)
            Next
        End With
    End Sub

    Private Sub frmsettings_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        PID = Nothing
        DID = Nothing
        fillPositions()
        fillDepartments()
    End Sub

    Private Sub btnPUpdate_Click(sender As Object, e As EventArgs) Handles btnPUpdate.Click
        If Not PID = Nothing Then
            With frmEditSettings
                .form = "Position"
                .ID = Me.PID
                .ShowDialog(Me)
            End With
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

    Private Sub btnPDelete_Click(sender As Object, e As EventArgs) Handles btnPDelete.Click
        If Not PID = Nothing Then
            pos.deletePosition(PID)
            PID = Nothing
            fillPositions()
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

    Private Sub btnDUpdate_Click(sender As Object, e As EventArgs) Handles btnDUpdate.Click
        If Not DID = Nothing Then
            With frmEditSettings
                .form = "Department"
                .ID = Me.DID
                .ShowDialog(Me)
            End With
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

    Private Sub btnDDelete_Click(sender As Object, e As EventArgs) Handles btnDDelete.Click
        If Not DID = Nothing Then
            dep.deleteDepartment(DID)
            DID = Nothing
            fillDepartments()
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub
End Class