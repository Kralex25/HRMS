﻿Public Class clsUsers : Inherits clsConnect
    Private _userid As Integer
    Private _username, _password, _usertype As String

    Public Property UserID As Integer
        Get
            Return _userid
        End Get
        Set(value As Integer)
            _userid = value
        End Set
    End Property

    Public Property Username As String
        Get
            Return _username
        End Get
        Set(value As String)
            _username = value
        End Set
    End Property

    Public Property Password As String
        Get
            Return _password
        End Get
        Set(value As String)
            _password = value
        End Set
    End Property

    Public Property Usertype As String
        Get
            Return _usertype
        End Get
        Set(value As String)
            _usertype = value
        End Set
    End Property

    Public Function GetAllUsers() As List(Of clsUsers)
        Dim list As New List(Of clsUsers)
        sql = "SELECT * from users"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim user As New clsUsers
                    user.UserID = rdr("userid")
                    user.Username = rdr("username")
                    user.Password = rdr("password")
                    user.Usertype = rdr("usertype")
                    list.Add(user)
                End While
            Catch ex As Exception
                MessageBox.Show("GetAllUsers: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Public Function GetUserByID(ByVal ID As Integer) As ArrayList
        Dim list As New ArrayList
        sql = "SELECT * from users WHERE userid=@id"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim user As New clsUsers
                    user.UserID = rdr("userid")
                    user.Username = rdr("username")
                    user.Password = rdr("password")
                    user.Usertype = rdr("usertype")
                    list.Add(user)
                End While
            Catch ex As Exception
                MessageBox.Show("GetUserByID: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function


    Public Function LogUser(ByVal Uname As String, ByVal Pword As String) As ArrayList
        Dim list As New ArrayList
        sql = "SELECT * from users WHERE [username]=@uname AND [password]=@pword"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@uname", Uname)
                .AddWithValue("@pword", Pword)
            End With
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim user As New clsUsers
                    user.Usertype = rdr("usertype")
                    list.Add(user)
                End While
            Catch ex As Exception
                MessageBox.Show("LogUser: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Function addUser() As Boolean
        If Connect() Then
            sql = "INSERT INTO users([username],[password],[usertype])VALUES" & _
                  "(@username,@password,@usertype)"
            cmd = New OleDb.OleDbCommand(Sql, cn)
            With cmd.Parameters
                .AddWithValue("@username", Username)
                .AddWithValue("@password", Password)
                .AddWithValue("@usertype", Usertype)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("addUser: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Function updateUser(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "UPDATE [users] SET [username]=@username,[password]=@password,[usertype]=@usertype WHERE userid=@id"
            cmd = New OleDb.OleDbCommand(Sql, cn)
            With cmd.Parameters
                .AddWithValue("@username", Username)
                .AddWithValue("@password", Password)
                .AddWithValue("@usertype", Usertype)
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("updateUser: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Function deleteUser(ByVal ID As Integer) As Boolean
        If Connect() Then
            Sql = "DELETE FROM users WHERE userid=@id"
            cmd = New OleDb.OleDbCommand(Sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show(" deleteUser: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function
End Class
