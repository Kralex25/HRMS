﻿Public Class clsLeaves : Inherits clsConnect
#Region "Properties"
    Private _empid, _leaveid As Integer
    Private _employeeid, _opt, _reason, _status, _name, _position, _department, _location As String
    Private _sdate, _edate, _stime, _etime As Date

    Public Property LeaveID As Integer
        Get
            Return _leaveid
        End Get
        Set(value As Integer)
            _leaveid = value
        End Set
    End Property

    Public Property EmpID As Integer
        Get
            Return _empid
        End Get
        Set(value As Integer)
            _empid = value
        End Set
    End Property

    Public Property EmployeeID As String
        Get
            Return _employeeid
        End Get
        Set(value As String)
            _employeeid = value
        End Set
    End Property

    Public Property Name As String
        Get
            Return _name
        End Get
        Set(value As String)
            _name = value
        End Set
    End Property

    Public Property Position As String
        Get
            Return _position
        End Get
        Set(value As String)
            _position = value
        End Set
    End Property

    Public Property Department As String
        Get
            Return _department
        End Get
        Set(value As String)
            _department = value
        End Set
    End Property

    Public Property Opt As String
        Get
            Return _opt
        End Get
        Set(value As String)
            _opt = value
        End Set
    End Property

    Public Property Reason As String
        Get
            Return _reason
        End Get
        Set(value As String)
            _reason = value
        End Set
    End Property

    Public Property Location As String
        Get
            Return _location
        End Get
        Set(value As String)
            _location = value
        End Set
    End Property

    Public Property Status As String
        Get
            Return _status
        End Get
        Set(value As String)
            _status = value
        End Set
    End Property

    Public Property SDate As Date
        Get
            Return _sdate
        End Get
        Set(value As Date)
            _sdate = value
        End Set
    End Property

    Public Property EDate As Date
        Get
            Return _edate
        End Get
        Set(value As Date)
            _edate = value
        End Set
    End Property

    Public Property STime As Date
        Get
            Return _stime
        End Get
        Set(value As Date)
            _stime = value
        End Set
    End Property

    Public Property ETime As Date
        Get
            Return _etime
        End Get
        Set(value As Date)
            _etime = value
        End Set
    End Property

#End Region

#Region "Methods"
    Public Function GetAllLeaves() As List(Of clsLeaves)
        Dim list As New List(Of clsLeaves)
        sql = "SELECT * from ((leaves INNER JOIN employees ON employees.empid=leaves.empid)" & _
              "INNER JOIN positions ON positions.positionid=employees.positionid) INNER JOIN " & _
              "departments ON departments.departmentid=employees.departmentid"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim leave As New clsLeaves
                    leave.LeaveID = rdr("leaveid")
                    leave.EmployeeID = rdr("employeeid")
                    leave.name = rdr("lastname") & ", " & rdr("firstname") & " " & rdr("mi")
                    leave.Position = rdr("pname")
                    leave.Department = rdr("dname")
                    leave.Opt = rdr("option")
                    leave.SDate = rdr("sdate")
                    leave.EDate = rdr("edate")
                    leave.Reason = rdr("reason")
                    leave.Status = rdr("stat")
                    list.Add(leave)
                End While
            Catch ex As Exception
                MessageBox.Show("GetAllLeaves: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Public Function GetLeavebyID(ByVal ID As Integer) As ArrayList

        Dim list As New ArrayList
        sql = "SELECT * from leaves  WHERE leaveid=@id"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim leave As New clsLeaves
                    leave.EmpID = rdr("empid")
                    leave.Opt = rdr("option")
                    leave.SDate = rdr("sdate")
                    leave.EDate = rdr("edate")
                    leave.Reason = rdr("reason")
                    leave.Status = rdr("stat")
                    list.Add(leave)
                End While
            Catch ex As Exception
                MessageBox.Show("GetLeavebyID: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Public Function GetLeavebyReason(ByVal Reason As String) As List(Of clsLeaves)
        Dim list As New List(Of clsLeaves)
        sql = "SELECT * from ((leaves INNER JOIN employees ON employees.empid=leaves.empid)" & _
              "INNER JOIN positions ON positions.positionid=employees.positionid) INNER JOIN " & _
              "departments ON departments.departmentid=employees.departmentid WHERE reason=@reason"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@reason", Reason)
            End With
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim leave As New clsLeaves
                    leave.LeaveID = rdr("leaveid")
                    leave.EmployeeID = rdr("employeeid")
                    leave.Name = rdr("lastname") & ", " & rdr("firstname") & " " & rdr("mi")
                    leave.Position = rdr("pname")
                    leave.Department = rdr("dname")
                    leave.Opt = rdr("option")
                    leave.SDate = rdr("sdate")
                    leave.EDate = rdr("edate")
                    leave.Reason = rdr("reason")
                    leave.Status = rdr("stat")
                    list.Add(leave)
                End While
            Catch ex As Exception
                MessageBox.Show("GetLeavebyReason: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Function addLeave() As Boolean
        If Connect() Then
            sql = "INSERT INTO leaves(empid,[option],sdate,edate,reason,stat)VALUES(@empid,@opt,@sdate,@edate,@reason,@stat)"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@empid", CInt(EmpID))
                .AddWithValue("@opt", Opt)
                .AddWithValue("@sdate", SDate)
                .AddWithValue("@edate", EDate)
                .AddWithValue("@reason", Reason)
                .AddWithValue("@stat", Status)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("addLeave: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Function updateLeave(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "UPDATE leaves SET empid=@empid,[option]=@opt,sdate=@sdate,edate=@edate," & _
                  "reason=@reason WHERE leaveid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@empid", EmpID)
                .AddWithValue("@opt", Opt)
                .AddWithValue("@sdate", SDate)
                .AddWithValue("@edate", EDate)
                .AddWithValue("@reason", Reason)
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("updateLeave: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Public Function deleteLeave(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "DELETE FROM leaves WHERE leaveid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("deleteLeave: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Function approveLeave(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "UPDATE leaves SET stat=@stat WHERE leaveid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@stat", Status)
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("approveLeave: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function
#End Region

End Class
