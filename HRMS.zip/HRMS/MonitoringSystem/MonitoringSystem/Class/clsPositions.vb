﻿Public Class clsPositions : Inherits clsConnect
#Region "Properties"
    Private _positionid As Integer
    Private _name As String

    Public Property PositionID As Integer
        Get
            Return _positionid
        End Get
        Set(value As Integer)
            _positionid = value
        End Set
    End Property

    Public Property Name As String
        Get
            Return _name
        End Get
        Set(value As String)
            _name = value
        End Set
    End Property
#End Region
#Region "Methods"
    Public Function GetAllPositions() As List(Of clsPositions)
        Dim list As New List(Of clsPositions)
        sql = "SELECT * from positions"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim position As New clsPositions
                    position.PositionID = rdr("positionid")
                    position.Name = rdr("pname")
                    list.Add(position)
                End While
            Catch ex As Exception
                MessageBox.Show("GetAllPositions: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Public Function GetPositionbyID(ByVal ID As Integer) As ArrayList
        Dim list As New ArrayList
        sql = "SELECT * from positions WHERE positionid=@id"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim position As New clsPositions
                    position.PositionID = rdr("positionid")
                    position.Name = rdr("pname")
                    list.Add(position)
                End While
            Catch ex As Exception
                MessageBox.Show("GetPositionbyID: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Function addPosition() As Boolean
        If Connect() Then
            sql = "INSERT INTO positions(pname)VALUES(@name)"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@name", Name)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("addPosition: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Function updatePosition(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "UPDATE positions SET pname=@name WHERE positionid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@name", Name)
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("updatePosition: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Public Function deletePosition(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "DELETE FROM positions WHERE positionid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("deletePosition: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function
#End Region

End Class
