﻿Public Class clsEmployees : Inherits clsConnect
#Region "Properties"
    Private _employeeid, _firstname, _lastname, _mi, _address, _civilstatus,
            _sex, _contact, _birthplace, _econtact, _method, _status, _position,
            _department As String
    Private _birthdate, _datehired As Date
    Private _rate, _ttlleave, _remleave As Double
    Private _empid, _positionid, _departmentid As Integer

    Public Property EmpID As Integer
        Get
            Return _empid
        End Get
        Set(value As Integer)
            _empid = value
        End Set
    End Property

    Public Property PositionID As Integer
        Get
            Return _positionid
        End Get
        Set(value As Integer)
            _positionid = value
        End Set
    End Property

    Public Property DepartmentID As Integer
        Get
            Return _departmentid
        End Get
        Set(value As Integer)
            _departmentid = value
        End Set
    End Property

    Public Property EmployeeID As String
        Get
            Return _employeeid
        End Get
        Set(value As String)
            _employeeid = value
        End Set
    End Property

    Public Property Lastname As String
        Get
            Return _lastname
        End Get
        Set(value As String)
            _lastname = value
        End Set
    End Property

    Public Property Firstname As String
        Get
            Return _firstname
        End Get
        Set(value As String)
            _firstname = value
        End Set
    End Property

    Public Property MI As String
        Get
            Return _mi
        End Get
        Set(value As String)
            _mi = value
        End Set
    End Property

    Public Property Address As String
        Get
            Return _address
        End Get
        Set(value As String)
            _address = value
        End Set
    End Property

    Public Property CivilStatus As String
        Get
            Return _civilstatus
        End Get
        Set(value As String)
            _civilstatus = value
        End Set
    End Property

    Public Property Sex As String
        Get
            Return _sex
        End Get
        Set(value As String)
            _sex = value
        End Set
    End Property

    Public Property Contact As String
        Get
            Return _contact
        End Get
        Set(value As String)
            _contact = value
        End Set
    End Property

    Public Property Birthplace As String
        Get
            Return _birthplace
        End Get
        Set(value As String)
            _birthplace = value
        End Set
    End Property

    Public Property EContact As String
        Get
            Return _econtact
        End Get
        Set(value As String)
            _econtact = value
        End Set
    End Property

    Public Property Method As String
        Get
            Return _method
        End Get
        Set(value As String)
            _method = value
        End Set
    End Property

    Public Property Status As String
        Get
            Return _status
        End Get
        Set(value As String)
            _status = value
        End Set
    End Property

    Public Property Position As String
        Get
            Return _position
        End Get
        Set(value As String)
            _position = value
        End Set
    End Property

    Public Property Department As String
        Get
            Return _department
        End Get
        Set(value As String)
            _department = value
        End Set
    End Property

    Public Property Birthdate As Date
        Get
            Return _birthdate
        End Get
        Set(value As Date)
            _birthdate = value
        End Set
    End Property

    Public Property DateHired As Date
        Get
            Return _datehired
        End Get
        Set(value As Date)
            _datehired = value
        End Set
    End Property

    Public Property Rate As Double
        Get
            Return _rate
        End Get
        Set(value As Double)
            _rate = value
        End Set
    End Property

    Public Property TotalLeave As Double
        Get
            Return _rate
        End Get
        Set(value As Double)
            _rate = value
        End Set
    End Property

    Public Property RemainingLeave As Double
        Get
            Return _remleave
        End Get
        Set(value As Double)
            _remleave = value
        End Set
    End Property
#End Region

#Region "Methods"
    Public Function GetAllEmployees() As List(Of clsEmployees)
        Dim list As New List(Of clsEmployees)
        sql = "SELECT * from (employees INNER JOIN positions ON " & _
              "positions.positionid=employees.positionid) INNER JOIN departments ON " & _
              "departments.departmentid=employees.departmentid"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim e As New clsEmployees
                    e.EmpID = rdr("empid")
                    e.EmployeeID = rdr("employeeid")
                    e.Lastname = rdr("lastname")
                    e.Firstname = rdr("firstname")
                    e.MI = rdr("mi")
                    e.Address = rdr("address")
                    e.CivilStatus = rdr("civilstatus")
                    e.Sex = rdr("sex")
                    e.Contact = rdr("contact")
                    e.Birthdate = rdr("birthdate")
                    e.Birthplace = rdr("birthplace")
                    e.EContact = rdr("econtact")
                    e.Rate = rdr("rate")
                    e.Position = rdr("pname")
                    e.Department = rdr("dname")
                    e.DateHired = rdr("datehired")
                    e.Method = rdr("method")
                    e.Status = rdr("status")
                    list.Add(e)
                End While
            Catch ex As Exception
                MessageBox.Show("GetAllEmployees: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Public Function GetEmployeeByID(ByVal ID As Integer) As ArrayList
        Dim list As New ArrayList
        sql = "SELECT * from (employees INNER JOIN positions ON " & _
              "positions.positionid=employees.positionid) INNER JOIN departments ON " & _
              "departments.departmentid=employees.departmentid WHERE empid=@id"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim e As New clsEmployees
                    e.EmployeeID = rdr("employeeid")
                    e.Lastname = rdr("lastname")
                    e.Firstname = rdr("firstname")
                    e.MI = rdr("mi")
                    e.Address = rdr("address")
                    e.CivilStatus = rdr("civilstatus")
                    e.Sex = rdr("sex")
                    e.Contact = rdr("contact")
                    e.Birthdate = rdr("birthdate")
                    e.Birthplace = rdr("birthplace")
                    e.EContact = rdr("econtact")
                    e.Rate = rdr("rate")
                    e.Position = rdr("pname")
                    e.Department = rdr("dname")
                    e.DateHired = rdr("datehired")
                    e.Method = rdr("method")
                    e.Status = rdr("status")
                    list.Add(e)
                End While
            Catch ex As Exception
                MessageBox.Show("GetEmployeeByID: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Function addEmployee() As Boolean
        MsgBox(EmployeeID)
        If Connect() Then
            sql = "INSERT INTO employees(employeeid,lastname,firstname,mi,address,civilstatus,sex," & _
                  "contact,birthdate,birthplace,econtact,rate,positionid,departmentid,datehired,method,status)VALUES(@employeeid," & _
                  "@lastname,@firstname,@mi,@address,@civilstatus,@sex,@contact,@birthdate,@birthplace,@econtact," & _
                  "@rate,@pid,@did,@datehired,@method,@status)"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@employeeid", EmployeeID)
                .AddWithValue("@lastname", Lastname)
                .AddWithValue("@firstname", Firstname)
                .AddWithValue("@mi", MI)
                .AddWithValue("@address", Address)
                .AddWithValue("@civilstatus", CivilStatus)
                .AddWithValue("@sex", Sex)
                .AddWithValue("@contact", Contact)
                .AddWithValue("@birthdate", Birthdate)
                .AddWithValue("@birthplace", Birthplace)
                .AddWithValue("@econtact", EContact)
                .AddWithValue("@rate", Rate)
                .AddWithValue("@pid", PositionID)
                .AddWithValue("@did", DepartmentID)
                .AddWithValue("@datehired", DateHired)
                .AddWithValue("@method", Method)
                .AddWithValue("@status", Status)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("addPosition: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Function updateEmployee(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "UPDATE employees SET employeeid=@employeeid,lastname=@lastname,firstname=@firstname," & _
                   "mi=@mi,Address=@address,civilstatus=@civilstatus,sex=@sex,contact=@contact,birthdate=@birthdate," & _
                  "birthplace=@birthplace,econtact=@econtact,rate=@rate,positionid=@pid,departmentid=@did," & _
                  "datehired=@datehired,method=@method,status=@status WHERE empid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@employeeid", EmployeeID)
                .AddWithValue("@lastname", Lastname)
                .AddWithValue("@firstname", Firstname)
                .AddWithValue("@mi", MI)
                .AddWithValue("@address", Address)
                .AddWithValue("@civilstatus", CivilStatus)
                .AddWithValue("@sex", Sex)
                .AddWithValue("@contact", Contact)
                .AddWithValue("@birthdate", Birthdate)
                .AddWithValue("@birthplace", Birthplace)
                .AddWithValue("@econtact", EContact)
                .AddWithValue("@rate", Rate)
                .AddWithValue("@pid", PositionID)
                .AddWithValue("@did", DepartmentID)
                .AddWithValue("@datehired", DateHired)
                .AddWithValue("@method", Method)
                .AddWithValue("@status", Status)
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("updateEmployee: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Public Function deleteEmployee(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "DELETE FROM employees WHERE empid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("deleteEmployee: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function
#End Region
    
End Class
