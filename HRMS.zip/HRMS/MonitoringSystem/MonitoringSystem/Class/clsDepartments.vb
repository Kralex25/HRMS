﻿Public Class clsDepartments : Inherits clsConnect
#Region "Properties"
    Private _deptid As Integer
    Private _name As String

    Public Property DepartmentID As Integer
        Get
            Return _deptid
        End Get
        Set(value As Integer)
            _deptid = value
        End Set
    End Property

    Public Property Name As String
        Get
            Return _name
        End Get
        Set(value As String)
            _name = value
        End Set
    End Property
#End Region
    
#Region "Methods"
    Public Function GetAllDepartments() As List(Of clsDepartments)
        Dim list As New List(Of clsDepartments)
        sql = "SELECT * from departments"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim department As New clsDepartments
                    department.DepartmentID = rdr("departmentid")
                    department.Name = rdr("dname")
                    list.Add(department)
                End While
            Catch ex As Exception
                MessageBox.Show("GetAllDepartments: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Public Function GetDepartmentbyID(ByVal ID As Integer) As ArrayList
        Dim list As New ArrayList
        sql = "SELECT * FROM departments WHERE departmentid=@id"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim department As New clsDepartments
                    department.Name = rdr("dname")
                    list.Add(department)
                End While
            Catch ex As Exception
                MessageBox.Show("GetDepartmentbyID: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Function addDepartment() As Boolean
        If Connect() Then
            sql = "INSERT INTO departments(dname)VALUES(@name)"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@name", Name)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("addDepartment: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Function updateDepartment(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "UPDATE departments SET dname=@name WHERE departmentid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@name", Name)
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("updateDepartment: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Public Function deleteDepartment(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "DELETE FROM departments WHERE departmentid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("deleteDepartment: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function
#End Region
    
End Class
