﻿Public Module modMisc
    Public Structure userInfo
        Public usertype As String
    End Structure
End Module
